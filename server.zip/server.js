const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
require("dotenv").config();

const app = express();

app.use(cors());
app.use(express.json());


// =========================
// MYSQL CONNECTION
// =========================

const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT
});

db.connect((err) => {
    if (err) {
        console.log("Database connection failed:", err);
        return;
    }

    console.log("MySQL database connected successfully!");
});


// =========================
// HOME ROUTE
// =========================

app.get("/", (req, res) => {
    res.send("Library Management Backend is running!");
});


// =========================
// GET ALL BOOKS
// =========================

app.get("/api/books", (req, res) => {

    const sql = `
        SELECT
            books.book_id,
            books.title,
            authors.author_name,
            books.category,
            books.quantity
        FROM books
        JOIN authors
            ON books.author_id = authors.author_id
        ORDER BY books.book_id;
    `;

    db.query(sql, (err, results) => {

        if (err) {
            console.log("Error fetching books:", err);

            return res.status(500).json({
                error: "Failed to fetch books"
            });
        }

        res.json(results);
    });
});


// =========================
// GET ALL STUDENTS
// =========================

app.get("/api/students", (req, res) => {

    const sql = `
        SELECT
            student_id,
            name,
            department,
            phone
        FROM students
        ORDER BY student_id;
    `;

    db.query(sql, (err, results) => {

        if (err) {
            console.log("Error fetching students:", err);

            return res.status(500).json({
                error: "Failed to fetch students"
            });
        }

        res.json(results);
    });
});


// =========================
// GET ALL ISSUED BOOKS
// =========================

app.get("/api/issues", (req, res) => {

    const sql = `
        SELECT
            issued_books.issue_id,
            students.name AS student_name,
            books.title AS book_title,
            authors.author_name,
            issued_books.issue_date,
            issued_books.due_date,
            issued_books.return_date,
            issued_books.status
        FROM issued_books
        JOIN students
            ON issued_books.student_id = students.student_id
        JOIN books
            ON issued_books.book_id = books.book_id
        JOIN authors
            ON books.author_id = authors.author_id
        ORDER BY issued_books.issue_id DESC;
    `;

    db.query(sql, (err, results) => {

        if (err) {
            console.log("Error fetching issued books:", err);

            return res.status(500).json({
                error: "Failed to fetch issued books"
            });
        }

        res.json(results);
    });
});


// =========================
// DASHBOARD DATA
// =========================

app.get("/api/dashboard", (req, res) => {

    const sql = `
        SELECT
            (SELECT COUNT(*) FROM books) AS total_books,
            (SELECT COUNT(*) FROM students) AS total_students,
            (SELECT COUNT(*) FROM issued_books WHERE status = 'Issued') AS issued_books,
            (SELECT COUNT(*) FROM issued_books WHERE status = 'Returned') AS returned_books,
            (SELECT COALESCE(SUM(quantity), 0) FROM books) AS available_copies;
    `;

    db.query(sql, (err, results) => {

        if (err) {
            console.log("Error fetching dashboard data:", err);

            return res.status(500).json({
                error: "Failed to fetch dashboard data"
            });
        }

        res.json(results[0]);
    });
});


// =========================
// TEST ROUTE
// =========================

app.get("/test", (req, res) => {
    res.send("Test route is working!");
});


// =========================
// ADD NEW STUDENT
// =========================

app.post("/api/students", (req, res) => {

    const { name, department, phone } = req.body;

    const sql = `
        INSERT INTO students (name, department, phone)
        VALUES (?, ?, ?)
    `;

    db.query(
        sql,
        [name, department, phone],
        (err, result) => {

            if (err) {
                console.log("Error adding student:", err);

                return res.status(500).json({
                    error: "Failed to add student"
                });
            }

            res.json({
                message: "Student added successfully",
                student_id: result.insertId
            });
        }
    );
});


// =========================
// ISSUE A BOOK
// =========================

app.post("/api/issue", (req, res) => {

    const {
        student_id,
        book_id,
        issue_date,
        due_date
    } = req.body;

    const sql = `
        INSERT INTO issued_books
        (student_id, book_id, issue_date, due_date, status)
        VALUES (?, ?, ?, ?, 'Issued')
    `;

    db.query(
        sql,
        [student_id, book_id, issue_date, due_date],
        (err, result) => {

            if (err) {
                console.log("Error issuing book:", err);

                return res.status(500).json({
                    error: "Failed to issue book"
                });
            }

            const updateBook = `
                UPDATE books
                SET quantity = quantity - 1
                WHERE book_id = ?
                AND quantity > 0
            `;

            db.query(
                updateBook,
                [book_id],
                (err) => {

                    if (err) {
                        console.log(
                            "Error updating book quantity:",
                            err
                        );

                        return res.status(500).json({
                            error:
                                "Book issued but quantity update failed"
                        });
                    }

                    res.json({
                        message: "Book issued successfully",
                        issue_id: result.insertId
                    });
                }
            );
        }
    );
});


// =========================
// RETURN A BOOK
// =========================

app.put("/api/return/:issue_id", (req, res) => {

    const issueId = req.params.issue_id;

    const returnDate =
        new Date().toISOString().split("T")[0];

    const findIssue = `
        SELECT book_id
        FROM issued_books
        WHERE issue_id = ?
        AND status = 'Issued'
    `;

    db.query(
        findIssue,
        [issueId],
        (err, results) => {

            if (err) {

                return res.status(500).json({
                    error: "Failed to find issue"
                });
            }

            if (results.length === 0) {

                return res.status(404).json({
                    error:
                        "Issue record not found or already returned"
                });
            }

            const bookId = results[0].book_id;

            const updateIssue = `
                UPDATE issued_books
                SET return_date = ?, status = 'Returned'
                WHERE issue_id = ?
            `;

            db.query(
                updateIssue,
                [returnDate, issueId],
                (err) => {

                    if (err) {

                        return res.status(500).json({
                            error: "Failed to return book"
                        });
                    }

                    const updateBook = `
                        UPDATE books
                        SET quantity = quantity + 1
                        WHERE book_id = ?
                    `;

                    db.query(
                        updateBook,
                        [bookId],
                        (err) => {

                            if (err) {

                                return res.status(500).json({
                                    error:
                                        "Book returned but quantity update failed"
                                });
                            }

                            res.json({
                                message:
                                    "Book returned successfully"
                            });
                        }
                    );
                }
            );
        }
    );
});


// =========================
// START SERVER
// =========================

const PORT = 5000;

app.listen(PORT, () => {
    console.log(
        `Server running on http://localhost:${PORT}`
    );
});